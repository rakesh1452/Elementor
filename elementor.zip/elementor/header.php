<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Elementor
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="sub-header">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-xs-12">
            <ul class="left-info">
              <li><a href="#"><i class="fa fa-clock-o"></i>Mon-Fri 09:00-17:00</a></li>
              <li><a href="#"><i class="fa fa-phone"></i>090-080-0760</a></li>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="right-icons">
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa fa-behance"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

	<header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
			<a class="navbar-brand" href="<?php echo home_url(); ?>">
				<?php 
				if (has_custom_logo()) {
					the_custom_logo(); // displays the logo image
				} else {
					// fallback to site title if logo not set
					echo '<h2>' . get_bloginfo('name') . '</h2>';
				}
				?>
			</a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          
          <?php echo 
          wp_nav_menu(array(
            'menu' => 'main-menu', // Leaving it empty removes the <div> container.
            'container' => 'div',
            'container_class' => 'collapse navbar-collapse', 
            'container_id' => 'navbarResponsive', 
            'menu_class' => 'navbar-nav ml-auto',
            'walker' => new WP_Bootstrap_Navwalker() 
          )); 
          ?>
        </div>
      </nav>
    </header>

	
