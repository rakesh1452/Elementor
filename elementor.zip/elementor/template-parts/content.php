<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Elementor
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

  <!-- Page Heading Section -->
  <div class="page-heading header-text">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
			<h1><?php echo the_title();?></h1>
          <span><?php the_excerpt(); ?></span>
        </div>
      </div>
    </div>
  </div>

  <!-- Content and Image Section -->
  <div class="container my-5">
    <div class="row align-items-center">
      
      <!-- Image Side -->
      <div class="col-md-6">
        <?php if ( has_post_thumbnail() ) : ?>
          <div class="post-thumbnail">
            <?php the_post_thumbnail('large', ['class' => 'img-fluid']); ?>
          </div>
        <?php endif; ?>
		
      </div>

      <!-- Content Side -->
      <div class="col-md-6">
        <div class="entry-header">
          <?php
            the_title( '<h2 class="entry-title">', '</h2>' );
            if ( 'post' === get_post_type() ) :
          ?>
		  
          
          <?php endif; ?>
		  
        </div>

        <div class="entry-content">
          <?php
            the_content();

            wp_link_pages(array(
              'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'elementor' ),
              'after'  => '</div>',
            ));
          ?>

			<div class="entry-meta mt-3">
            <?php
              elementor_posted_on();
              elementor_posted_by();
            ?>
          </div>
		  
        </div>
      </div>
    </div>
  </div>


  
</article>

